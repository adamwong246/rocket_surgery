# RocketSurgery

This mod will make rocketry much more difficult. 

## Rocket Sile Construction
You must now build your rocket silo on-sight, in stages. Credits to https://mods.factorio.com/mod/Rocket-Silo-Construction

## Pollution
Everything produces more pollution. 
- Each stage of the rocket sile construction
- The construction of rocket parts
- The launch itself produces a wave of pollution. Be prepared for biter retaliation!

## Electricity
Everything requires more electricity. 

## debufs
- The silo's max health is reduced from 3000 to 1000.
- The silo no longer has any resistances.
- The silo is now a military target.

