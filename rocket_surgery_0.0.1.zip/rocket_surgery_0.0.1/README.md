# RocketSurgery

This mod will make rocketry much more difficult. 

## Rocket Sile Construction
You must now build your rocket silo on-sight, in stages. Credits to https://mods.factorio.com/mod/Rocket-Silo-Construction

## Pollution
Everything produces more pollution. 
- Each stage of the rocket sile construction
- The construction of rocket parts
- The launch itself produces a wave of pollution. Be prepared for biter retaliation!

## Electricity
The rocket silo requires more electricity. 