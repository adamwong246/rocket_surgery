# RocketSurgery

This mod will make all rocketry much more difficult. 

## Rocket Sile Construction
You must now build your rocket silo on-sight, in stages. Credits to https://mods.factorio.com/mod/Rocket-Silo-Construction

## Pollution
Both the silo and the rocket produce much more pollution. Be prepared for a wave of pollution after each launch.

## Water is required.
The construction of the rocket within the silo requires a source of water. 

## Launch windows
Once the rocket begins the launch sequence, the silo's energy usage, as well as emissions, will spike. If you lose power to the silo during this period, the rocket will begin to lose health.

